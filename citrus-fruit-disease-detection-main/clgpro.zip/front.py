import streamlit as st

#sidebar
st.sidebar.title("Dashboard")
app_mode= st.sidebar.selectbox("Select Page",["Home","About","Features","Prediction"])

#Main page
if (app_mode=="Home"): 
    st.header("Citrus Fruit Disease Detection Using Machine Learning")
    st.image("./home.jpg")

#About
elif(app_mode=="About"):
    st.header("About")
    st.subheader("Introduction:")
    paragraph = """Citrus fruit detection plays a vital role in various industries, including agriculture and food processing. Accurately identifying and classifying citrus fruits such as oranges, lemons, and limes is crucial for quality control, sorting, and grading processes. Traditional methods of fruit inspection are time-consuming and labor-intensive, highlighting the need for automated detection systems.

In recent years, advancements in computer vision and machine learning have revolutionized fruit detection, enabling fast and accurate identification of citrus fruits based on their visual characteristics. These technologies have the potential to streamline fruit sorting processes, reduce waste, and improve overall efficiency in the citrus industry.

This project aims to develop a citrus fruit detection system using deep learning techniques. By leveraging the power of convolutional neural networks (CNNs) and image processing algorithms, we can create a robust solution capable of accurately detecting and classifying citrus fruits in real-time."""
    st.write(paragraph)
    st.subheader("Dataset:")


#Features
elif(app_mode=="Features"):
    st.header("Features")
    st.image("./easy.png",width=200)
    st.text("Just need to click and upload fruit image.")
    st.write('')
    
    st.image("./cause.png",width=250)
    st.text("Provides the cause and solution of the identified diseases.")
    st.write('')

    st.image("./large.png",width=250)
    st.text("Supports around Different Citrus fruit.")

#Prediction
elif(app_mode=="Prediction"):
    st.header("Prediction")
    st.subheader("Test Your Fruit:")
    test_image=st.file_uploader("Choose an Image:")
    if(st.button("Show Image")):
        st.image(test_image,width=4,use_column_width=True)

    #prediction button
    if(st.button("Predict")):
        st.write("Our Prediction")
